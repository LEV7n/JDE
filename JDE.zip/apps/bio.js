/**
 * Composite and render user bio
 * Developed By Michael Levinez
 *
 * @class Bio
 */
class Bio {
    /*Class defaults*/
    profile = { Name: '', Born: '', Location: [], Photo: '', About: '' };
    skills = [];

    /**
     * Add person data
     *
     * @param {Object} data
     * @return Bio
     */
    addPerson(data) {
        this.profile = Object.assign({}, this.profile, data);

        return this;
    }

    /**
     * Add skills to stack
     *
     * @param {Array, Object} skill
     * @return Bio
     */
    addSkills(skill) {
        if (Array.isArray(skill))
            this.skills = this.skills.concat(skill);
        else if (skill.hasOwnProperty('Name'))
            this.skills.push(skill);

        return this;
    }

    /**
     * Render given info
     * @return DocumentFragment
     */
    render() {
        const
            data = Object.assign({}, this.profile, { Skills: this.skills }),
            fragment = document.createDocumentFragment(),
            table = document.createElement('table'),
            tbody = document.createElement('tbody');

        Object.keys(data).forEach((key) => {
            const
                row = document.createElement('tr'),
                heading = document.createElement('th'),
                content = document.createElement('td');

            heading.setAttribute('width', '80px');
            heading.style.fontWeight = 'bold';
            heading.innerText = `${ key }:`;

            content.innerHTML = (() => {
                switch (key) {
                    case 'Born': return `<b>${ new Date(data[key]).toISOString() }<b/>`;
                    case 'Location': return `<b>${ data[key].join(', ') }<b/>`;
                    case 'Photo': return `<img src="${ data[key] }" />`;
                    case 'About': return `<i style="font-weight:bold;">${ data[key] }</i>`;
                    case 'Skills': {
                        return data[key].map((skill) => {
                            return `<b>${ skill.Name }</b>\
${ skill.Frameworks ? `: (${ skill.Frameworks.map((m) => m).join(', ') }),` : ',' } \
<i>Since: <b>${ skill.Since }</b> year.</i>`
                        }).join('<br>');
                    }
                    default: return `<b>${ data[key] }<b/>`;
                }
            })();

            row.append(heading);
            row.append(content);
            tbody.append(row);
        });

        table.append(tbody);
        fragment.append(table);

        return fragment;
    }
}

/**
 * Launch application
 *
 * @return {{title: string, content: DocumentFragment}}
 */
export default () => {
    /*Create user bio*/
    const
        person = new Bio()
            .addPerson({
                Name: 'Michael Levinez', Born: '03/12/1989 09:15 GMT+3', Location: [ '55°9.2412′N', '61°25.749′E' ],
                Photo: 'img/photo.jpg',
                About: `Hello, i am senior javascript developer.<br>\
    For 12 years of experience i have developed a lot of different difficult level tasks,<br>\
    including javascript on different frameworks and also Chrome Extensions.<br>\
    Also good know php, worked with laravel. Have skills in Vue.js (router, vuex).<br>\
    Learning Kotlin to do Android apps.`
            })
            .addSkills([
                { Name: 'HTML 4.1/5', Since: '2010' },
                { Name: 'CSS 2.1/3', Since: '2010' },
                { Name: 'Javascript', Frameworks: [ 'jQuery', 'MooTools', 'Prototype' ], Since: '2011' },
                { Name: 'Javascript', Frameworks: [ 'Zepto', 'Angular', 'React', 'Backbone', 'Vue.js' ], Since: '2015' },
                { Name: 'DB', Frameworks: [ 'MySQL/MariaDB', 'PostgreSQL', 'Mongo' ], Since: '2012' },
                { Name: 'Chrome Extensions', Since: '2015' },
                { Name: 'PHP', Frameworks: [ 'Laravel' ], Since: '2020' },
                { Name: 'Kotlin', Since: '2021' },
            ]);

    return {
        title: `${ person.profile.Name }'s Bio`,
        content: person.render()
    };
};