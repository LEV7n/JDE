import Helper from "./helper.js";

/**
 * Create and manage windows
 * Developed By Michael Levinez
 *
 * @class Window
 */
export default class Window {
    /*Class defaults*/
    #winID = 0;
    windows = {};

    /**
     * Create window
     *
     * @param {Object} data
     * @param {String} [data.icon]
     * @param {String} [data.title]
     * @param {String} [data.parent]
     * @param {HTMLElement, DocumentFragment} data.content
     *
     * @return Object
     */
    createWindow(data) {
        const
            id = ++this.#winID,
            window = document.createElement('div'),
            heading = document.createElement('div'),
            icon = document.createElement('i'),
            name = document.createElement('span'),
            content = document.createElement('div'),
            isPath = /\/.+\.[0-9-a-z]{3,5}$/.test(data?.icon);

        window.id = id.toString();
        window.classList.add('window');
        window.style.setProperty('--id', id.toString());

        /*Set position*/
        if (data?.position) {
            Object.keys(data.position)
                .forEach((key) => {
                    window.style[key] = data.position[key] + (typeof data.position[key] === 'number' ? 'px' : '');
                });
        }

        icon.classList.add('icon', !isPath ? 'material-icons-outlined' : 'static');
        icon.innerHTML = !isPath ? (data?.icon || 'question_mark') : `<img src="${ data?.icon }" />`;

        heading.append(icon);

        name.classList.add('name');
        name.innerText = data?.title || 'Unknown';
        heading.append(name);

        heading.classList.add('title', 'no-select');

        content.classList.add('content');
        content.append(data?.content);

        window.append(heading);
        window.append(content);
        (data?.parent || document.body).append(window);

        this.windows[id] = {
            window: window,
            above: null,
            heading: heading,
            title: (value) => !value ? name.innerText : name.innerText = value,
            controls: this.#createWindowControls({
                windowID: this.#winID,
                window: window,
                heading: heading,
                buttons: [ 'minimize', 'toggle', 'close' ]
            }),
            content: content
        };

        /*Select on single click*/
        Helper.delegate('click', '.window', (e, target) => {
            Object.keys(this.windows).forEach((id) =>
                this.#blurWindow(id));
            this.#focusWindow(target.id);
        });

        Object.keys(this.windows).forEach((id) =>
            this.#blurWindow(id));
        this.#focusWindow(id);

        return this.windows[id];
    }

    /**
     * Create window controls
     *
     * @param {Object} data
     * @param {Number} data.windowID
     * @param {HTMLDivElement} data.window
     * @param {HTMLDivElement} data.heading
     * @param {Object} data.buttons
     *
     * @return Object
     */
    #createWindowControls(data) {
        const
            { windowID, window, heading } = data,
            buttons = document.createElement('div');
        buttons.classList.add('buttons-holder');

        data.buttons.forEach((type) => {
            const
                button = document.createElement('button');
            button.classList.add(`btn-${ type }`);
            button.classList.add('material-icons-outlined');
            button.innerText = type === 'toggle' ? 'crop_din' : type;

            button.addEventListener('click', (e) => {
                e.preventDefault();

                switch (type) {
                    case 'minimize': return this.#minimize(window, e);
                    case 'toggle': return this.#toggle(window, e);
                    case 'close': return this.#close(windowID);
                }
            }, false);

            buttons.append(button);
        });

        heading.append(buttons);

        return {
            holder: buttons,
            buttons: buttons.querySelectorAll('button')
        }
    }

    /**
     * Focus window by ID
     *
     * @param {Number, String} id
     */
    #focusWindow(id) {
        if (this.windows[id] && !this.windows[id].above)
            this.windows[id].window.style.zIndex = '1001';
    }

    /**
     * Blur window by ID
     *
     * @param {Number, String} id
     */
    #blurWindow(id) {
        if (this.windows[id] && !this.windows[id].above)
            this.windows[id].window.style.zIndex = '';
    }

    /**
     * Make window above others ID
     *
     * @param {Number, String} id
     */
    #windowAbove(id) {
        if (this.windows[id])
            this.windows[id].window.style.zIndex = '2001';
            this.windows[id].above = true;
    }

    /**
     * Make window below others ID
     *
     * @param {Number, String} id
     */
    #windowBelow(id) {
        if (this.windows[id])
            this.windows[id].window.style.zIndex = '';
            this.windows[id].above = false;
    }

    /**
     * Destroy window by ID
     *
     * @param {Number, String} id
     */
    #destroyWindow(id) {
        if (this.windows[id]) {
            this.windows[id].window.remove();
            delete this.windows[id];
        }
    }

    /**
     * Minimize window
     *
     * @param window
     * @param {MouseEvent} e
     */
    #minimize(window, e) {
        if (!window.classList.contains('minimized'))
            window.classList.add('minimized');
    }

    /**
     * Normalize/Maximize window
     *
     * @param window
     * @param {MouseEvent} e
     */
    #toggle(window, e) {
        if (!window.classList.contains('minimized'))
            window.classList.toggle('maximized');
            e.target.innerText = window.classList.contains('maximized') ? 'filter_none' : 'crop_din';

        window.classList.remove('minimized');
    }

    /**
     * Close window
     *
     * @param windowID
     */
    #close(windowID) {
        this.#destroyWindow(windowID);
    }
}

/*Import needed styles*/
Helper.importStyle([ 'css/window.css' ]);